---Information sur les fichiers MNT---
ils doivent être dans le système de coordonnées locales
