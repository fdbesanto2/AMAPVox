java -jar -Xmx25g VoxeLidarGUIFX-1.0.jar
