/*
 * filter.cpp
 *
 *  Created on: 21 mai 2013
 *      Author: theveny
 */

#include "shotfilter.h"

shotfilter::shotfilter() {
	// TODO Auto-generated constructor stub

}

shotfilter::~shotfilter() {
	// TODO Auto-generated destructor stub
}

